package com.desafiodeeconomia.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import kotlin.random.Random

private val Black = Color(0xFF101010)
private val Panel = Color(0xFF1C1C1C)
private val Gold = Color(0xFFFFC83D)
private val White = Color(0xFFF7F7F7)
private val Muted = Color(0xFFB8B8B8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("economia", MODE_PRIVATE)
        setContent {
            var target by remember { mutableStateOf(prefs.getFloat("target", 500f).toDouble()) }
            var amountText by remember { mutableStateOf("500") }
            var countText by remember { mutableStateOf("50") }
            var challengeName by remember { mutableStateOf(prefs.getString("name", "Meu primeiro desafio") ?: "Meu primeiro desafio") }
            var values by remember { mutableStateOf(loadValues(prefs.getString("values", null))) }
            var checked by remember { mutableStateOf(loadChecked(prefs.getString("checked", null), values.size)) }
            var showCreate by remember { mutableStateOf(false) }
            var message by remember { mutableStateOf("Toque nos quadradinhos conforme guardar dinheiro.") }

            fun persist() {
                prefs.edit()
                    .putFloat("target", target.toFloat())
                    .putString("name", challengeName)
                    .putString("values", JSONArray(values).toString())
                    .putString("checked", JSONArray(checked.map { it }).toString())
                    .apply()
            }

            MaterialTheme(colorScheme = darkColorScheme(
                primary = Gold, background = Black, surface = Panel,
                onPrimary = Black, onBackground = White, onSurface = White
            )) {
                Surface(Modifier.fillMaxSize(), color = Black) {
                    Column(Modifier.fillMaxSize().padding(18.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("DESAFIO DE", color = Muted, fontSize = 12.sp, letterSpacing = 2.sp)
                                Text("ECONOMIA", color = Gold, fontSize = 27.sp, fontWeight = FontWeight.Black)
                            }
                            Text("R$", color = Gold, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.height(18.dp))
                        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                            Column(Modifier.padding(18.dp)) {
                                Text(challengeName, color = White, fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
                                Spacer(Modifier.height(10.dp))
                                Text("TOTAL GUARDADO", color = Muted, fontSize = 11.sp, letterSpacing = 1.5.sp)
                                Text("R$ ${money(values.indices.filter { checked.getOrElse(it) { false } }.sumOf { values[it] })}", color = Gold, fontSize = 31.sp, fontWeight = FontWeight.Bold)
                                val saved = values.indices.filter { checked.getOrElse(it) { false } }.sumOf { values[it] }
                                val pct = if (target > 0) (saved / target).coerceIn(0.0, 1.0).toFloat() else 0f
                                LinearProgressIndicator(progress = { pct }, modifier = Modifier.fillMaxWidth().height(9.dp), color = Gold, trackColor = Color.DarkGray)
                                Spacer(Modifier.height(7.dp))
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Meta: R$ ${money(target)}", color = Muted, fontSize = 12.sp)
                                    Text("${(pct * 100).toInt()}%", color = Gold, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                                Spacer(Modifier.height(12.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    StatBox("DEPÓSITOS", "${checked.count { it }}", Modifier.weight(1f))
                                    StatBox("QUADRINHOS", "${values.size}", Modifier.weight(1f))
                                    StatBox("FALTAM", "${values.size - checked.count { it }}", Modifier.weight(1f))
                                }
                            }
                        }
                        Spacer(Modifier.height(16.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("SEU DESAFIO", color = White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            TextButton(onClick = { showCreate = true }) { Text("+ NOVO", color = Gold, fontWeight = FontWeight.Bold) }
                        }
                        Text(message, color = Muted, fontSize = 12.sp)
                        Spacer(Modifier.height(10.dp))
                        LazyVerticalGrid(
                            columns = GridCells.Fixed(4),
                            modifier = Modifier.weight(1f),
                            contentPadding = PaddingValues(bottom = 8.dp),
                            verticalArrangement = Arrangement.spacedBy(9.dp),
                            horizontalArrangement = Arrangement.spacedBy(9.dp)
                        ) {
                            itemsIndexed(values) { index, value ->
                                val done = checked.getOrElse(index) { false }
                                Card(
                                    modifier = Modifier.aspectRatio(1f).clickable {
                                        checked = checked.toMutableList().also { it[index] = !it[index] }
                                        persist()
                                    },
                                    colors = CardDefaults.cardColors(containerColor = if (done) Gold else Panel),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text(if (done) "✓" else "R$", color = if (done) Black else Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                            Text(money(value), color = if (done) Black else White, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold)
                                        }
                                    }
                                }
                            }
                        }
                        Button(
                            onClick = { showCreate = true },
                            modifier = Modifier.fillMaxWidth().height(52.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Black),
                            shape = RoundedCornerShape(14.dp)
                        ) { Text("CRIAR NOVO DESAFIO", fontWeight = FontWeight.Black) }
                    }
                }

                if (showCreate) {
                    AlertDialog(
                        onDismissRequest = { showCreate = false },
                        containerColor = Panel,
                        title = { Text("Criar desafio automático", color = Gold, fontWeight = FontWeight.Bold) },
                        text = {
                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                OutlinedTextField(value = challengeName, onValueChange = { challengeName = it }, label = { Text("Nome do desafio") }, singleLine = true)
                                OutlinedTextField(value = amountText, onValueChange = { amountText = it.filter { c -> c.isDigit() } }, label = { Text("Meta em reais (ex.: 500)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                                OutlinedTextField(value = countText, onValueChange = { countText = it.filter { c -> c.isDigit() } }, label = { Text("Quantidade de depósitos (5 a 200)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
                                Text("O aplicativo distribui valores variados que somam exatamente a sua meta.", color = Muted, fontSize = 12.sp)
                            }
                        },
                        confirmButton = {
                            TextButton(onClick = {
                                val total = amountText.toIntOrNull()?.coerceIn(1, 100000) ?: 500
                                val n = countText.toIntOrNull()?.coerceIn(5, 200) ?: 50
                                val generated = generateChallenge(total, n)
                                target = total.toDouble()
                                values = generated
                                checked = List(generated.size) { false }
                                challengeName = challengeName.ifBlank { "Meu desafio" }
                                message = "Novo desafio criado! Marque cada valor quando guardar."
                                persist()
                                showCreate = false
                            }) { Text("GERAR DESAFIO", color = Gold, fontWeight = FontWeight.Bold) }
                        },
                        dismissButton = { TextButton(onClick = { showCreate = false }) { Text("CANCELAR", color = Muted) } }
                    )
                }
            }
        }
    }
}

@Composable
private fun StatBox(label: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Color(0xFF292929)), shape = RoundedCornerShape(12.dp)) {
        Column(Modifier.padding(10.dp)) {
            Text(label, color = Muted, fontSize = 9.sp)
            Text(value, color = Gold, fontSize = 19.sp, fontWeight = FontWeight.Bold)
        }
    }
}

private fun generateChallenge(totalReais: Int, count: Int): List<Int> {
    val cents = totalReais * 100
    val base = cents / count
    var remainder = cents % count
    val result = MutableList(count) { base }
    val order = (0 until count).shuffled()
    for (i in order) {
        if (remainder == 0) break
        result[i] += 1
        remainder--
    }
    // Convert to cents internally then distribute whole and broken-real values.
    // Keep values as reais with centavos represented as rounded random variation only where possible.
    val exactCents = result.shuffled()
    val reais = exactCents.map { it / 100 }
    val leftover = totalReais - reais.sum()
    val adjusted = reais.toMutableList()
    for (i in 0 until leftover) adjusted[i % count] += 1
    return adjusted.shuffled()
}

private fun loadValues(raw: String?): List<Int> {
    if (raw == null) return generateChallenge(500, 50)
    return try {
        val a = JSONArray(raw); (0 until a.length()).map { a.getInt(it) }
    } catch (_: Exception) { generateChallenge(500, 50) }
}

private fun loadChecked(raw: String?, size: Int): List<Boolean> {
    if (raw == null) return List(size) { false }
    return try {
        val a = JSONArray(raw); List(size) { i -> if (i < a.length()) a.getBoolean(i) else false }
    } catch (_: Exception) { List(size) { false } }
}

private fun money(value: Number): String {
    val v = value.toDouble()
    return if (v % 1.0 == 0.0) String.format("%,.0f", v).replace(",", ".")
    else String.format("%,.2f", v).replace(",", "X").replace(".", ",").replace("X", ".")
}
